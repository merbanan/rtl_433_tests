// ****************************************************************************
//
// COPYRIGHT 2012 AyDeeKay LLC - All Rights Reserved
// No part of this document can be used, copied, transmitted, or modified by
// any existing or to be invented means without express approval of AyDeeKay
// LLC.
//
// ****************************************************************************
//
// File:
//   HeimdallSlave.h
//
// Description:  
//   Definitions and function declarations for Chaviero IC
//
// ****************************************************************************
//
// REVISION HISTORY
//
// Version   Date:        By:          Description:
// V0.01.01  01/03/2014   David Chen   Added PIR defination
// V0.01.00  04/18/2012   Scott Kee    Unify various versions into one file
//
// **************************************************************************** 

/////////////////////////////////////////////////////////////////////////////// 
/// @file HeimdallSlave.h
///
/// @brief Definitions and function declarations for Chaviero IC
///
/// @author Scott Kee
///////////////////////////////////////////////////////////////////////////////


#ifndef __HEIMDALLSLAVE_H__
#define __HEIMDALLSLAVE_H__


// ********************************************************************************************************************
// IRQ enumeration - must be defined before core_cm0.h loaded
// ********************************************************************************************************************

/// Interrupt table:
///   TX_RELOAD_IRQn => pended whenever the TX buffer should be reloaded during an RF transmission
///   TX_DONE_IRQn   => pended whenever an RF transmission burst is completed
///   WAKEUP_IRQn    => wakeup timer overflow
///   TIMER0_IRQn    => TIMER0 overflow
///   TIMER1_IRQn    => TIMER1 overflow
///   TIMER2_IRQn    => TIMER2 overflow
///   WATCHDOG_IRQn  => watchdog timer timout (when configured)
typedef enum IRQn
{
  //***** Exceptions Numbers ****************************
  NonMaskableInt_IRQn         = -14,    // Non Maskable Interrupt                             
  HardFault_IRQn              = -13,    // Hard Fault Interrupt                     
  SVCall_IRQn                 = -5,     // SV Call Interrupt                       
  PendSV_IRQn                 = -2,     // Pend SV Interrupt                       
  SysTick_IRQn                = -1,     // SysTick Interrupt                   

  //***** Interrupt Numbers *****************************
  TX_RELOAD_IRQn              = 0,      // Indication to reload TX buffer                                 
  TX_DONE_IRQn                = 1,      // Indication of burst end
  IRQ02_IRQn                  = 2,      // Not assigned
  WAKEUP_IRQn                 = 3,      // Wakeup timer overflow 
  IRQ04_IRQn                  = 4,      // Not assigned
  IRQ05_IRQn                  = 5,      // Not assigned
  IRQ06_IRQn                  = 6,      // Not assigned
  IRQ07_IRQn                  = 7,      // Not assigned
  IRQ08_IRQn                  = 8,      // Not assigned
  IRQ09_IRQn                  = 9,      // Not assigned
  IRQ10_IRQn                  = 10,     // Not assigned
  IRQ11_IRQn                  = 11,     // Not assigned
  IRQ12_IRQn                  = 12,     // Not assigned
  IRQ13_IRQn                  = 13,     // Not assigned
  IRQ14_IRQn                  = 14,     // Not assigned
  IRQ15_IRQn                  = 15,     // Not assigned
  TIMER0_IRQn                 = 16,     // Timer 0
  TIMER1_IRQn                 = 17,     // Timer 1
  TIMER2_IRQn                 = 18,     // Timer 2
  WATCHDOG_IRQn               = 19      // Watchdog timer
} IRQn_Type;


#include "../clough/clough_core.h"
#include <stdint.h>


// ********************************************************************************************************************
// Clock / Power Management
// ********************************************************************************************************************

/// Clock control register:
/// CLKCTRL => { <N/A> , SRC , CLKDIV[1:0] , TRIMDIV[3:0] }
///
/// SRC: determines which clock is supplied to the MCU:
///   1 => crystal oscillator    use: CLKCTRL_SRC_XTAL
///   0 => 10kHz RC oscillator   use: CLKCTRL_SRC_RC
///
/// CLKDIV: determines the division ratio for the clock
///   00 => full speed clock.    use: CLKCTRL_CLKDIV_1
///   01 => divide by 2.         use: CLKCTRL_CLKDIV_2     
///   10 => divide by 4.         use: CLKCTRL_CLKDIV_4
///   11 => divide by 8.         use: CLKCTRL_CLKDIV_8
/// 
/// TRIMDIV: reserved.
///   must write 0001.           use: CLKCTRL_TRIMDIV
///
#define CLKCTRL   ((__IO uint8_t *) (ASIC_7B_BASE + 0x02))
#define	CLKCTRL_SRC_XTAL ((uint8_t) (0x01 << 6))
#define	CLKCTRL_SRC_RC	 ((uint8_t) (0x00 << 6))
#define	CLKCTRL_CLKDIV_1 ((uint8_t) (0x00 << 4))
#define	CLKCTRL_CLKDIV_2 ((uint8_t) (0x01 << 4))
#define	CLKCTRL_CLKDIV_4 ((uint8_t) (0x02 << 4))
#define	CLKCTRL_CLKDIV_8 ((uint8_t) (0x03 << 4))
#define CLKCTRL_TRIMDIV  ((uint8_t) (0x01 << 0))


/// RC oscillator calibration register
/// RCCAL => { STARTCAL , FREQSEL , CALMODE , CALVAL[4:0] }
///
/// STARTCAL: initiates a calibration
///   1 => starts a calibration.   use: RCOCTRL_STARTCAL
///
/// FREQSEL: controls which crystal oscillator is assumed
/// during calibration and for RF chip rate timing.
///   0 => 30MHz crystal.   use: RCOCTRL_FREQSEL_30M
///   1 => 20MHz crystal    use: RCOCTRL_FREQSEL_20M
///
/// CALMODE: controls whether automatic calibration or manual
/// trim values are used.
///   0 => trim from auto cal     use: RCOCTRL_CALMODE_AUTO
///   1 => trim from CALVAL       use: RCOCTRL_CALMODE_MANUAL
///
/// CALVAL: manual calibration trim. 
///
#define RCOCTRL    ((__IO uint8_t *) (ASIC_7B_BASE + 0x10))
#define RCOCTRL_STARTCAL       ((uint8_t) (0x01 << 7))
#define RCOCTRL_FREQSEL_20M    ((uint8_t) (0x01 << 6))
#define RCOCTRL_FREQSEL_30M    ((uint8_t) (0x00 << 6))
#define RCOCTRL_CALMODE_MANUAL ((uint8_t) (0x01 << 5))
#define RCOCTRL_CALMODE_AUTO   ((uint8_t) (0x00 << 5))


/// Power management control
/// UCCTRL => { SWPWRDN , <N/A> , VSRAMEN , RCOSCEN , AUTOXTAL , SWXTALEN , SOFTCLR , WKTEN }
///
/// SWPWRDN: initiates a deep sleep (power down).  Note that this should *not* be done
/// unless certain other conditions are met:
/// - Some method of wakeup should be enabled, either the wakeup timer or a pin change wake up.
/// - The VDDPDEN bit should be set.
/// - Then RC oscillator should be enabled and selected as the MCU clock source
///   1 => starts a deep sleep.   use: UCCTRL_SWPWRDN
///
/// VSRAMEN: enables an ultra low power voltage regulator to hold the MCU state during a
/// deep sleep.  If this bit is not set and a deep sleep occurs then the MCU will reboot when
/// waking up from sleep.  If this bit is set, a small bias current is consumed to keep the
/// MCU state intact during sleep so that the MCU continues from the previous state when
/// waking up.  Most batter transmitter applications should use this bit set to 0 and write
/// the software to expect a reboot on every deep sleep.
///   0 => power down
///   1 => hold state    use: UCCTRL_VSRAMEN
///
/// RCOSCEN: enable the RC oscillator bias.
///   0 => disabled
///   1 => enabled       use: UCCTRL_RCOSCEN
///
/// AUTOXTAL: automatically enable crystal oscillator any time MCU is not sleeping
///   1 => crystal oscillator bias enabled whenever MCU is running.  bias is also
///        enabled during deep sleep if SWXTALEN is also enabled.
///        use: UCCTRL_AUTOXTAL
///   0 => crystal oscillator bias enabled if SWXTALEN is enabled
///
/// SWXTALEN: software enable of crystal oscillator bias
///   0 => crystal oscillator bias is enabled only if MCU is running AND AUTOXTAL
///        is set.
///   1 => crystal oscillator bias is enabled.
///        use: UCCTRL_SWXTALEN
///
/// SOFTCLR: software clear/reset of control register values for ASIC die peripherals.
/// Many such peripherals do not get reset during software reset/reboot.  Writing this
/// bit can perform software clear on these registers similar to a power-on reset.
///   1 => perform a software clear.
///        use: UCCTRL_SOFTCLR
///
/// WKTEN: wakeup timer enable.  When in deep sleep, this timer can be used to wake up
/// based on an elapsed time.
///   0 => wakeup timer disabled.  deep sleep only ends if a pin wakeup occurs
///   1 => wakeup timer enabled.  deep sleep can end due to this timer OR pin change wakeup
///        use: UCCTRL_WKTEN
///
#define UCCTRL ((__IO uint8_t *) (ASIC_7B_BASE + 0x15))
#define UCCTRL_SWPWRDN  ((uint8_t) (0x01 << 7))
#define UCCTRL_PIREN    ((uint8_t) (0x01 << 6))
#define UCCTRL_VSRAMEN  ((uint8_t) (0x01 << 5))
#define UCCTRL_RCOSCEN  ((uint8_t) (0x01 << 4))
#define	UCCTRL_AUTOXTAL	((uint8_t) (0x01 << 3))
#define	UCCTRL_SWXTALEN	((uint8_t) (0x01 << 2))
#define UCCTRL_SOFTCLR  ((uint8_t) (0x01 << 1))
#define UCCTRL_WKTEN    ((uint8_t) (0x01 << 0))


/// Wakeup timer load  value
/// WKTIME => { WKTMANT[3:0] , WKTEXP[3:0] }
/// 
/// WKTMANT: mantissa of the wakeup timer load value
///
/// WKTEXP: exponent of the wakeup timer load value
///
/// The value loaded is: 4 * WKTMANT * 2^(WKTEXP)
///
#define WKTIME ((__IO uint8_t *) (ASIC_7B_BASE + 0x11))


/// PMU Trim registers
/// PMUTRIM0: reserved, only ever write 0x8840
/// PMUTRIM1: reserved, only ever write 0x26
#define PMUTRIM0     ((__IO uint16_t *) (ASIC_16B_BASE + 0x00))
#define PMUTRIM0_VAL ((uint16_t) 0x8840)
#define PMUTRIM1     ((__IO uint8_t *) (ASIC_16B_BASE + 0x0B))
#define PMUTRIM1_VAL ((uint8_t) 0x26)


// ********************************************************************************************************************
// RF Transmitter
// ********************************************************************************************************************


/// TXCONFIG: RF transmitter configuration
/// TXCONFIG->TXCTRL0 => { STARTX , NXTBURST , MODUL[1:0] , FRAC_EN , RESERVED[2:0] }
/// TXCONFIG->TXCTRL1 => { PEDES[1:0] , TPATCH[10:5] }
/// TXCONFIG->POWLEV  => { POWLEV[7:0] }
/// TSCONFIG->POWAP   => { ASKAMP[7:0] }
///
/// STARTX: initiate an RF burst
///   1 => start a transmission burst with the current settings
///        use: TXCTRL0_STARTX
///
/// NXTBURST: indicate to repeat the current burst again once the current one
/// completes.   This bit is checked at the end of each rf transmission burst.
/// if set, then another burst is initiated automatically without needing to
/// set STARTX again.  This bit can be adjusted during transmission.
///   0 => transmitter will become idle after current burst
///   1 => transmitter will start new burst after current one.
///        use: TXCTRL0_NXTBURST
///
/// MODUL: modulation format to use
///   00 => reserved
///   01 => BPSK            use: TXCTRL0_MODUL_PSK
///   10 => BFSK            use: TXCTRL0_MODUL_FSK
///   11 => ASK             use: TXCTRL0_MODUL_ASK
///
/// FRAC_EN: enable fractional-N feature of PLL
///   0 => integer-N PLL mode
///   1 => fractional-N PLL mode   use: TXCTRL0_FRAC_EN
///
/// TXCTRL0[2:0]: reserved.  only write 3'b000
///
/// PEDES: Controls power level set during TDET3.  
///   00 => 0x10   use: TXCTRL1_PEDES_10
///   01 => 0x12   use: TXCTRL1_PEDES_12
///   10 => 0x14   use: TXCTRL1_PEDES_14
///   11 => 0x16   use: TXCTRL1_PEDES_16
///
/// TPATCH[10:5]:  Allows fine tuning of the time between message bursts
/// when NXTBURST is set.  Since the NWAIT parameter only allows integer
/// number so of chip times to be set for the inter-burst waiting period
/// this register can be used to add a small delay with finer resolution
/// to produce the desired time.  The approximate time resolution for
/// this variable is 800ns and is unaffected by CKDIV.  Note that only
/// the MSBs of this parameter are stored in this register.  The MSBs are
/// stored in the TXTIMING register.
///
/// POWLEV:  Power level for FSK, and for logic level 0 of ASK.  When using
/// FSK modulation, the output power os controlled by this register.  When
/// using ASK modulation, the power level output during the low level chips
/// is controlled by this register.  To do on-off keying ASK, set this to
/// 0.  Ignored in BPSK mode.
///
/// ASKAMP:  Power level for BPSK, and for logic level 1 of ASK.  Ignored
/// in FSK mode.
///
typedef struct
{
  __IO uint8_t TXCTRL0;  // { STARTX , NXTBURST , MODUL[1:0] , FRAC_EN , RESERVED[2:0] }
  __IO uint8_t TXCTRL1;  // { PEDES[1:0] , TPATCH[10:5] }
  __IO uint8_t POWLEV;   // { POWLEV[7:0] }
  __IO uint8_t POWAP;    // { ASKAMP[7:0] }
} TXCTRLType;

#define TXCTRL ((TXCTRLType *) (ASIC_7B_BASE + 0x04))
#define TXCTRL0_MODUL_ASK ((uint8_t) (0x03 << 4))
#define TXCTRL0_MODUL_PSK ((uint8_t) (0x01 << 4))
#define TXCTRL0_MODUL_FSK ((uint8_t) (0x02 << 4))
#define TXCTRL0_FRAC_EN   ((uint8_t) (0x01 << 3))
#define TXCTRL0_NXTBURST  ((uint8_t) (0x01 << 6))
#define TXCTRL0_STARTX    ((uint8_t) (0x01 << 7))
#define TXCTRL1_PEDES_10 ((uint8_t) (0x00 << 6))
#define TXCTRL1_PEDES_12 ((uint8_t) (0x01 << 6))
#define TXCTRL1_PEDES_14 ((uint8_t) (0x02 << 6))
#define TXCTRL1_PEDES_16 ((uint8_t) (0x03 << 6))


/// TXDAT: Transmit data buffer.  This buffer must be periodically written to
/// with transmit data during the rf transmission.  Before the transmission
/// begins, it must contain the first 16 chips to be transmitted.  After
/// approximately 8 chips have been transmitted, a TX_RELOAD_IRQn will be
/// generated indicating the buffer should be written to with the next
/// 16 chips.  Chips are transmitted out of the buffer MSB first.  If the
/// number of chips to be transmitted is not a multiple of 16, then the
/// most-significant bits of the last buffer update are the ones transmitted. 
typedef union
{
  __IO uint16_t HWORD;
  __IO uint8_t  BYTE[2];
} TXDATType;

#define TXDAT ((TXDATType *) (ASIC_7B_BASE + 0x08))


/// TXMSGFMT: Transmit message format control
/// TXMSGFMT->BYTE[0] => { NWAIT[5:0] , NXBITS[9:8] }
/// TXMSGFMT->BYTE[1] => { NXBITS[7:0] }
///
/// NWAIT: Number of chip periods to wait between transmission bursts.
/// This register can be adjusted for the *NEXT* inter-burst period after
/// an inter-burst period commences without affecting the number of chips
/// periods for the current inter-burst period.
///
/// NXBITS: Number of tranmsission chips in the burst.  This register can
/// be adjusted for the *NEXT* burst after a burst commences without
/// affecting the number of chips transmitted during that burst.
///
typedef union
{
  __IO uint16_t HWORD;   // { NWAIT[5:0] , NXBITS[9:0] }
  __IO uint8_t  BYTE[2]; // BYTE[1] => { NWAIT[5:0] , NXBITS[9:8] }
                         // BYTE[0] => {              NXBITS[7:0] }
} TXMSGFMTType;

#define TXMSGFMT ((TXMSGFMTType *) (ASIC_7B_BASE + 0x0A))


/// TXTIMING: TX timing control
///
/// TXTIMING->CLKDIV.BYTE[1] => { TPATCH[4:0] , TXCLKDIV[10:8] }
/// TXTIMING->CLKDIV.BYTE[0] => {               TXCLKDIV[7:0]  }
/// TXTIMING->TDET.BYTE[1]   => { TDET3[2:0] , TDET4[4:0] }
/// TXTIMING->TDET.BYTE[0]   => { TRAMP[3:0] , TDET2[2:0] , TDET1 }
///
/// TPATCH[4:0]: see description in TXCONFIG section
///
/// TXCLKDIV: controls chip rate for the rf message.  This number
/// multiplied by approximately 800ns to determine the duration of
/// each transmitted chip.
///
/// TDET1: controls time between analog bias enable and PLL enable
/// (bias settling time).
///   0 => 1.6 us  (recommended)
///   1 => 8.0 us
///
/// TDET2: controls time between PLL enable and PA enable (PLL settling time).
/// The delay is (1+TDET2*1024)*800ns.  Recommended value is 3'b010.
///
/// TDET3: controls the time between PA enable and power ramp up (pedestal
/// time).  The delay is (1+TDET3*1024)*800ns.  Recommended value is 3'b101.
///
/// TDET4: controls the time between power ramp up and initiation of modulation
/// (power level settling).  The delay is (1+TDET4*1024)*800ns.  Recommended
/// value is 5'b10100.
///
typedef struct
{
  union
  {
    __IO uint16_t HWORD;     // HWORD   ==> { TPATCH[4:0] , TXCLKDIV[10:0]  }
	  __IO uint8_t  BYTE[2];   // BYTE[1] ==> { TPATCH[4:0] , TXCLKDIV[10:8] }
	                           // BYTE[0] ==> {               TXCLKDIV[7:0]  }
  }  CLKDIV;
  union
  {
    __IO uint16_t HWORD;    // HWORD   ==> { TRAMP[3:0] , TDET2[2:0] , TDET1 , TDET3[2:0] , TDET4[4:0] }
	  __IO uint8_t  BYTE[2];  // BYTE[1] ==> { TDET3[2:0] , TDET4[4:0] }
	                          // BYTE[0] ==> { TRAMP[3:0] , TDET2[2:0] , TDET1 }
  } TDET;
} TXTIMINGType;

#define TXTIMING ((TXTIMINGType *) (ASIC_7B_BASE + 0x0C))


/// PLLCTRL:  PLL frequency control
/// PLLCTRL->BYTE[0] => { NF[7:0] }
/// PLLCTRL->BYTE[1] => { NX[1:0] , NF[13:8] }
/// PLLCTRL->BYTE[2] => { LPFTRIM[1:0] , CPTRIM[2:0] , NX[4:2] }
/// PLLCTRL->BYTE[3] => { DF[5:0] , LPFTRIM[3:2] }
///
/// NF , NX:  Control the frequency multiplication ratio of the PLL.  The RF
/// transmit frequency will by fXTL * a multiplication ratio which is:
///   If FRAC_EN is 1 then:  8 + nx                  (integer-N mode)
///   If FRAC_EN is 1 hen:   9 + nx + nf/(2^14)      (fractional-N mode)
///
/// DF:  Frequency deviation of the logic 1 level in FSM mode.  This number is
/// added to NF during the logic 1 chips in FSK mode.  Ignored in other modes.
///
/// LPFTRIM:  Loop filter trim for PLL.  Recommended value is 4'b0011.
///
/// CPTRIM:  Charge pump trim for PLL.  Recommended value is 3'b001.
///
typedef union
{
  __IO uint32_t WORD;
  __IO uint16_t HWORD[2];  // HWORD[1] ==> { DF[5:0] , LPFTRIM[3:0] , CPTRIM[2:0] , NX[4:2] }
                           // HWORD[0] ==> { NX[1:0] , NF[13:0] }
  __IO uint8_t  BYTE[4];   // BYTE[3] ==> { DF[5:0] , LPFTRIM[3:2] }
                           // BYTE[2] ==> { LPFTRIM[1:0] , CPTRIM[2:0] , NX[4:2] }
						               // BYTE[1] ==> { NX[1:0] , NF[13:8] }
                           // BYTE[0] ==> { NF[7:0] }						   
}  PLLCTRLType;

#define PLLCTRL ((PLLCTRLType *) (ASIC_16B_BASE + 0x04))


/// TXTRIM0 - reserved, only ever write 0x44
/// TXTRIM1 - reserved, only ever write 0x82
#define TXTRIM0     ((__IO uint16_t *) (ASIC_16B_BASE + 0x03))
#define TXTRIM0_VAL ((uint8_t) 0x44)
#define TXTRIM1     ((__IO uint8_t *) (ASIC_16B_BASE + 0x0C))
#define TXTRIM1_VAL ((uint8_t) 0x82)


// ********************************************************************************************************************
// A/D Converter
// ********************************************************************************************************************

// ADCRES
#define ADCRES  ((__I uint8_t *) (ASIC_7B_BASE + 0x12))


// ADCCTRL0 ==> { reserved[1:0] , QPCLKL[1:0] , ADCCLK[1:0] , ADCCONT , ADCEN }
#define ADCCTRL0 ((__IO uint8_t *) (ASIC_7B_BASE + 0x13))

// ADCCTRL0 bitmask helpers
#define ADCCTRL0_QPCLK_DIV8   ((uint8_t) (0x00 << 4))
#define ADCCTRL0_QPCLK_DIV16  ((uint8_t) (0x01 << 4))
#define ADCCTRL0_QPCLK_DIV32  ((uint8_t) (0x02 << 4))
#define ADCCTRL0_QPCLK_DIV64  ((uint8_t) (0x03 << 4))
#define ADCCTRL0_ADCCLK_DIV8  ((uint8_t) (0x00 << 2))
#define ADCCTRL0_ADCCLK_DIV16 ((uint8_t) (0x01 << 2))
#define ADCCTRL0_ADCCLK_DIV32 ((uint8_t) (0x02 << 2))
#define ADCCTRL0_ADCCLK_DIV64 ((uint8_t) (0x03 << 2))
#define ADCCTRL0_ADCCONT      ((uint8_t) (0x01 << 1))
#define ADCCTRL0_ADCEN        ((uint8_t) (0x01 << 0))


// ADCMUX
#define ADCMUX ((__IO uint8_t *) (ASIC_7B_BASE + 0x14))

// ADCMUX value helpers
#define ADCMUX_GPIO0   ((uint8_t) 0x00)
#define ADCMUX_GPIO1   ((uint8_t) 0x01)
#define ADCMUX_GPIO2   ((uint8_t) 0x02)
#define ADCMUX_GPIO5   ((uint8_t) 0x05)
#define ADCMUX_GPIO6   ((uint8_t) 0x06)
#define ADCMUX_GPIO7   ((uint8_t) 0x07)
#define ADCMUX_GPIO8   ((uint8_t) 0x08)
#define ADCMUX_GPIO9   ((uint8_t) 0x09)
#define ADCMUX_GPIO10  ((uint8_t) 0x0A)
#define ADCMUX_GPIO11  ((uint8_t) 0x0B)
#define ADCMUX_TEMPSNS ((uint8_t) 0x0D)
#define ADCMUX_BGAP    ((uint8_t) 0x0E)


// ADCREF
typedef union
{
  __IO uint16_t HWORD;
  __IO uint8_t  BYTE[2];  // BYTE[1] ==> { reserved , ADCREFS , 2'b10 ,  ADCPGN[3:0] }
                          // BYTE[0] ==> { ADCREFLG[3:0] , ADCREFHG[3:0] }
} ADCREFType;

#define ADCREF ((ADCREFType *) (ASIC_16B_BASE + 0x08))


// ADCCTRL2 ==> { ADCXTRA[0:2] , ADCCAL , reserved , BLUEWR , REDWR , ADCCONTS }
#define ADCCTRL2 ((__IO uint8_t *) (ASIC_16B_BASE + 0x000A))

// ADCCTRL2 helpers
#define ADCCTRL2_ADCCONTS    ((uint8_t) (0x01 << 0))
#define ADCCTRL2_REDWR       ((uint8_t) (0x01 << 1))
#define ADCCTRL2_BLUEWR      ((uint8_t) (0x01 << 2))
#define ADCCTRL2_ADCCAL_BGAP ((uint8_t) (0x01 << 4))
#define ADCCTRL2_ADCCAL_VDD  ((uint8_t) (0x00 << 4))
#define ADCCTRL2_ADCXTRA_0   ((uint8_t) (0x00 << 5))
#define ADCCTRL2_ADCXTRA_1   ((uint8_t) (0x04 << 5))
#define ADCCTRL2_ADCXTRA_2   ((uint8_t) (0x02 << 5))
#define ADCCTRL2_ADCXTRA_3   ((uint8_t) (0x06 << 5))
#define ADCCTRL2_ADCXTRA_4   ((uint8_t) (0x01 << 5))
#define ADCCTRL2_ADCXTRA_5   ((uint8_t) (0x05 << 5))
#define ADCCTRL2_ADCXTRA_6   ((uint8_t) (0x03 << 5))
#define ADCCTRL2_ADCXTRA_7   ((uint8_t) (0x07 << 5))


// ********************************************************************************************************************
// PIR
// ********************************************************************************************************************

/// PIR:  PIR related registers.
///
/// PIR->PIRCNTR => {                           PIRC[7:0] }
/// PIR->PIRCTRL => { INHB[3:0] , PIRDIV[1:0] , PIRC[9:8] }
///
/// PIRC[9:0]: PIR event threshold counter
///
/// PIRDIV[1:0]: PIR devider bits
/// PIRDIV[1:0]=00: 10KHz/8
/// PIRDIV[1:0]=01: 10KHz/16
/// PIRDIV[1:0]=10: 10KHz/24
/// PIRDIV[1:0]=11: 10KHz/32
///
/// INHB[3:0]: Inhibit bits
///

typedef struct
{
  __IO uint8_t  PIRCNTR;
  __IO uint8_t  PIRCTRL;
} PIRType;

#define PIR ((PIRType *) (ASIC_7B_BASE + 0x00))

#define PIR_WAKEUP ((__IO uint8_t *) (ASIC_7B_BASE + 0x19))     // Register to record PIR wakeup or event flag
#define PIR_WUF 0x40                  // Bit 6 would be 1 if wakeup from PIR or if there is a PIR event. Clear by SW.

// ********************************************************************************************************************
// GPIO
// ********************************************************************************************************************


/// GPIOOE:  Output enable for GPIO pins.
///
/// GPIO->BYTE[0] => {                                        GPIOOE[7:0]  }
/// GPIO->BYTE[1] => { reserved , LEDCPEN , RLEDEN , BLEDEN , GPIOOE[11:8] }
///
/// GPIOOE[11:0]: Output enables for the GPIO0 through GPIO11.  Active high.
///
/// BLEDEN, RLEDEN:
///
/// LEDCPEN:
///
typedef union
{
  __IO uint16_t HWORD;
  __IO uint8_t  BYTE[2];   // BYTE[1] ==> { reserved , LEDCPEN , RLEDEN , BLEDEN , GPIOOE[11:8] }
                           // BYTE[0] ==> {                                        GPIOOE[7:0]  }
} GPIOOEType;

#define GPIOOE ((GPIOOEType *) (ASIC_7B_BASE + 0x16))


/// GPIO: GPIO read/write register
///
/// GPIO->BYTE[0] => {                 GPIO[7:0]  }
/// GPIO->BYTE[1] => { reserved[3:0] , GPIO[11:8] }
///
/// GPIO[11:0]:  Read/Write registers.  When written to, the pin value will
/// be driven to the level written for all pins which have GPIOOE bit set.
/// on read, returns the read-back value from the pins.
typedef union
{
  __IO uint16_t HWORD;    // HWORD   ==> { reserved[3:0] , GPIO[11:0] }
  __IO uint8_t  BYTE[2];  // BYTE[1] ==> { reserved[3:0] , GPIO[11:8] }
                          // BYTE[0] ==> { GPIO[7:0] }
} GPIOType;

#define GPIO ((GPIOType *) (ASIC_7B_BASE + 0x18))


/// GPIO Interrupt configuration registers:
/// GPIOCTRL1 ==> { IODEF[7:0] }
/// GPIOCTRL2 ==> { IOCEN[11:8] , IODEF[11:8] }
/// GPIOCTRL3 ==> { IOCEN[7:0] }
///
/// IODEF:  Default value for GPIOs.  For any pin which has IOCEN set to 1, the
/// chip will wake up from deep sleep if the pin value is not the same ad IODEF
///
/// IOCEN:  Wake up enable for GPIOs.  Each pin with this bit set to 1 will wake
/// the MCU from deep sleep if its pin value is ever different from that pin's
/// IODEF.
///
#define GPIOCTRL1 ((uint8_t *) (ASIC_7B_BASE + 0x1A))
#define GPIOCTRL2 ((uint8_t *) (ASIC_7B_BASE + 0x1B))
#define GPIOCTRL3 ((uint8_t *) (ASIC_7B_BASE + 0x1C))


/// GPIO pull up / down control
/// GPIOPUL1 ==> { PU_N[11] , PD[11] , PU_N[10] , PD[10] , PU_N[1] , PD[1] , PU_N[0] , PD[0] }
/// GPIOPUL2 ==> { PU_N[5] , PD[5] , reserved[2:0] , VDDPDEN , PU_N[2] , PD[2] }
/// GPIOPUL3 ==> { PU_N[9] , PD[9] , PU_N[8] , PD[8] , PU_N[7] , PD[7] , PU_N[6] , PD[6] }
///
/// PU_N[]:  Pull up enable for each pin.  This signal is ACTIVE LOW.
///
/// PD[]:  Pull down enable for each pin.  Active high.
///
/// VDDPDEN:  Only ever write this bit to 1.
///
#define GPIOPUL1 ((uint8_t *) (ASIC_16B_BASE + 0x0D))
#define GPIOPUL2 ((uint8_t *) (ASIC_16B_BASE + 0x10))
#define GPIOPUL3 ((uint8_t *) (ASIC_16B_BASE + 0x11))


/// GPIORE:  GPIO read enable
/// GPIORE->BYTE[0] => {                 RE[7:0]  }
/// GPIORE->BYTE[1] => { reserved[3:0] , RE[11:8] }
///
/// RE[]:  GPIO readback is enabled if its RE bit is set to 1.  Read from
/// GPIO register will return 0 if this bit is not set.
///
typedef union
{
  __IO uint16_t HWORD;    // HWORD   ==> { reserved[3:0] , RE[11:0] }
  __IO uint8_t  BYTE[2];  // BYTE[1] ==> { reserved[3:0] , RE[11:8] }
                          // BYTE[0] ==> {                 RE[7:0]  }
} GPIOREType;

#define GPIORE ((GPIOREType *) (ASIC_16B_BASE + 0x12))


// LEDTRIM => { LED2_ISEL[3:0] , LED1_ISEL[3:0] }
///
#define LEDTRIM    ((__IO uint8_t  *) (ASIC_16B_BASE + 0x0002))


#endif // __ HEIMDALL_SLAVE_H__
