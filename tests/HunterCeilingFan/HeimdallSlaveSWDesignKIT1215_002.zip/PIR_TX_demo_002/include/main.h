//********* Definition ************
#include <stdint.h>
#define TX_PREAMBLE_BITS 0      //32    // Bit count of raw preamble {0..31}
#define TX_PREAMBLE 0x80000000          // Content of raw preamble {0x00000000..0xFFFFFFFF}                
#define TX_ID_BITS 20                   // Bit count of ID {0..31}
#define TX_ID 0x0002C5BC                // Content of raw preamble {0x00000000..0xFFFFFFFF} 
#define TX_KEY_BITS 4                   // Bit count of keys {1..8}

#define NWAIT 30-(3+4)                  // Latency between two successive packets
#define TPATCH 0
#define CDIV 375                        // Symble rate =3.3K
#define TDET3 5
#define TDET4 0x14

#define N_RAW_BITS 4                    // Bit count of raw data for a digital bit{3..65535}
//#define RAW_BIT_1 0x0E                // Raw bits for digital 1 of EV format
//#define RAW_BIT_0 0x08                // Raw bits for digital 0 of EV format
#define RAW_BIT_1 0x08                  // Raw bits for digital 1 of uSesame decoder
#define RAW_BIT_0 0x0E                  // Raw bits for digital 0 of uSesame decoder

#define KEY_STOP_RAW_BIT_COUNT (TX_KEY_BITS * N_RAW_BITS)+8

// Calculate total bit length for burst transmission
#if (TX_PREAMBLE_BITS)
  #define BURST_BIT_SIZE TX_PREAMBLE_BITS+(TX_ID_BITS+TX_KEY_BITS)*N_RAW_BITS+8
#else
  #define BURST_BIT_SIZE (TX_ID_BITS+TX_KEY_BITS)*N_RAW_BITS+8
#endif

// Calculate count of half word fot TX data register
#if (!(BURST_BIT_SIZE >> 4))
  #define BURST_HWORD_SIZE (BURST_BIT_SIZE >> 4)
#else
  #define BURST_HWORD_SIZE ((BURST_BIT_SIZE >> 4)+1)
#endif

// Maximum time to transmit before sleeping (sat upon mode).  number of clock cycles at (fXTL / 8).
#define MAX_TX_TIME 56250000

// debounce count value.  port reads are seperated in time by approximately (8 * DEBOUNCE_COUNTS / fXTL)
#define DEBOUNCE_COUNTS 37500


//********* IO configuration ************

// Pin connections
// note: the port configuration is not automatically adjusted by setting these defines.  to change a button
// to a different pin, you will also need to edit the initGPIO() function to adjust the port config.  The port
// config for all momentary switches is pull up enabled , read enabled, pin change
#define BUTTON_0 ((uint16_t) (0x01 << 2))

#define BTN_PORTMASK      (BUTTON_0)

// values to write to GPIOPULx registers.  whichever pin is being used for REV (currently GPIO9) should have 00
// for its { PU_N , PD } bit pair.  It will be handled by the setRevBtnPulls() macro.  To change which pin has
// the toggle switch connected to it, you must change these defines, the setRevBtnPulls() macro and the setBtnPulls()
// macro.
// Current settings:
//   GPIO0  => high Z   
//   GPIO1  => high Z
//   GPIO2  => pull up    (Button 0)
//   GPIO5  => high Z
//   GPIO6  => high Z 
//   GPIO7  => high Z
//   GPIO8  => high Z
//   GPIO9  => high Z
//   GPIO10 => high Z
//   GPIO11 => high Z 

// { PU_N[11] , PD[11] , PU_N[10] , PD[10] , PU_N[1] , PD[1] , PU_N[0] , PD[0] }
// {    1     ,   0    ,    1     ,    0   ,   1     ,   0   ,    1    ,   0   }
#define GPIOPUL1_CFGVAL  ((uint8_t) 0xAA)

// { PU_N[5] , PD[5] , 4'b1010 , PU_N[2] , PD[2] }
// {   1     ,   0   , 1 0 1 1 ,   0     ,   0   }
#define GPIOPUL2_CFGVAL  ((uint8_t) 0xAC)

// { PU_N[9] , PD[9] , PU_N[8] , PD[8] , PU_N[7] , PD[7] , PU_N[6] , PD[6] }
// {   1     ,   0   ,   1     ,  0    ,   1     ,   0   ,   1     ,    0  }
#define GPIOPUL3_CFGVAL  ((uint8_t) 0xAA)

// value to write to the output enable.  LED pin should be zero in this define
#define GPIOOE_CFGVAL ((uint16_t) 0x0000)

// value to write to the read enable 
#define GPIORE_CFGVAL (BUTTON_0)

#define HAS_LED           1

// deep sleep wakeup timer between polling TX messages
// 4 * 5 + 2^9 = 10240 cycles ~= 1 second

#define WAKETIME_VAL (5 << 4) | 9;


// ********************************************************************************************************************
// ADC
// ********************************************************************************************************************
//use GPIO5 as ADC input
#define ADC_INPUT ((uint16_t) (0x01 << 5))

#define ADCREFHI  ((uint8_t) (15)) //0-15

#define ADCREFLO  ((uint8_t) (0<<4)) //0-15

#define ADCREFVBG (0x00)
#define ADCREFVDD (0x40)
#define ADCPGN    (15)     //0-15

//********* Type define ************
typedef struct RF_Info_type{
  const uint8_t nKey;                           // Number of keys
  uint16_t RawData[16], RawKeyDataEntryBit;     // Raw data buffers and bit mask for raw data generated
  volatile uint16_t* pRawKeyDataEntryHword;     // pointer of RAW data buffer for key data entry
  uint8_t Key;                                  // Records of key status
}RF_InfoType;

//********* global variable *********
extern RF_InfoType RF_Info;      // Create structure and initialize nKey
extern uint8_t rf_data_idx;                    // Data indexer for TX data register
extern uint8_t DataSendingEnable;
extern uint8_t DataSending;
