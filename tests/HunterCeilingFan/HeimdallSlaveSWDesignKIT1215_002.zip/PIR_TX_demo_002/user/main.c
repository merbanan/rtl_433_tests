// *****************************************************************************
// Heimdall Slave Demo Code
// This software is waken up by PIR event interrupt or pin change interrupt 
// or wake up timer, and send out TX packets when PIR event is detected. 
// After TX is done, it will go to sleep immediately. 
// When button is holded when power up, it will go to while loop for ADC measurement. 
// This is also the only way for you to connect to chip through Jlink debugger.

//TX Description
//RF data format for EV1527 which is one of the 
// popular RF data format in China.
//
// EV1527 preamble format is : 10000000000000000000000000000000b
// EV1527 data H is : 1110b
// EV1527 data L is : 1000b
// EV1527 data format is : Preamble + ID{C0..C19} + D0 D1 D2 D3
//
// There is no latency between two successive data packets. In the packet above,
// the first preamble would be discarded by uSesame. The send preamble that is 
// next to the last bit of key data would be considered as stop signal by uSesame.  
// So  Heimdall Slave emulates the packet as below.
//     ID + bit H +nWait
// Heimdall Slave serially send RF signals according to the constant of TX data upper 
// and TX data lower registers. MSB of the 16 bit data will be shifted first.
// In this case, for example, ID is 0x2C5BC, 20bits. So the raw data should be 
// shifted out as following data.
// 0xEE8E, 0x88EE, 0xE8E8, 0x8E88 and 0x88EE
//
// The hex data of 0x2C5BC is reformed to be binary format to 0010,1100,0101,
// 1011,1100b (i.e. 0x2,0xC,0x5,0xB,0xC). Each of digital bit would be transferred 
// to be 4 bits of EV1527 raw data so the raw data for the 20 digital bits are:
//   1000,1000,1110,1000b = 0x88E8 ==> 0x2
//   1110,1110,1000,1000b = 0xEE88 ==> 0xC
//   1000,1110,1000,1110b = 0x8E8E ==> 0x5
//   1110,1000,1110,1110b = 0xE8EE ==> 0xB
//   1110,1110,1000,1000b = 0xEE88 ==> 0xC
// But decoded data of uSesame is reverse to compare to EV1527's, so the raw 
// data should be: 0xEE8E, 0x88EE, 0xE8E8, 0x8E88 and 0x88EE.
// There are four bits of key data. Suppose they are 1110B of digital bits. The 
// raw data should be 0x888E. A 1000b is added at the end to be a stop bit for 
// uSesame. To trigger MinGB of uSesame, 0000b is added after the stop raw bits 
// is recommended. So in this example the whole raw data should be:
// 0xEE8E, 0x88EE, 0xE8E8, 0x8E88, 0x88EE, 0x888E, 0x8000
// The bust count should be 104.
//
// Note:
//      1. Press BUTTON_1 and BUTTON_3 at the same time can stop the device from sleeping
//      2. Two or more key buttons are pressed at the same time are not considered
//         in this demo code.
//      3. The following path should be added in the menu "Project->Option->c/c++ compiler->Preprocessor"
//              $PROJ_DIR$\include
//              $PROJ_DIR$\include\heimdallslave
//              $PROJ_DIR$\include\clough
//              $TOOLKIT_DIR$\CMSIS\include
//

// Released by Yupeng Zhang               12/04/2015
// *****************************************************************************


#include "heimdallslave.h"
#include "main.h"

//********* Global variables ************
RF_InfoType RF_Info={TX_KEY_BITS};      // Create structure and initialize nKey
uint8_t rf_data_idx;                    // Data indexer for TX data register
uint8_t DataSendingEnable=0;
uint8_t DataSending=0;



//-----------------------------------------
//
//
//-----------------------------------------
  void Init_Clock ( void )
  {
  // Xtal had been enabled @ cstartup_M.c and had been switched to be system clock source @ "low_level_init.c" 

    *CLKCTRL = *CLKCTRL | CLKCTRL_CLKDIV_8;     //Clock is divided by 8 to save current
  }



//********* Program entry ************
int main()
{
  uint16_t load, i;

  Init_Clock ();                        //switch to XT_clock/8  
  Init_GPIO ();                         //Initialize I/O pins to allow for wakeup on change
  Init_ADC ();
 
  // start up TIMER0.  we will let this one free run to perform simple delays.
  // additionally, we will pre-load the max tx time and check if it still negative
  // to decide whether to keep transmitting in some cases
  TIMER0->CTRL   = TIMER_CFG_ENA;
  TIMER0->COUNT = -MAX_TX_TIME;
  *WKTIME = 0x6A;   //set wake up timer around 300ms = 4(6*2^7)*0.1ms
  NVIC_ClearPendingIRQ(WAKEUP_IRQn);
  NVIC_EnableIRQ( WAKEUP_IRQn );
  
  if (*PIR_WAKEUP & PIR_WUF) {            // Check if Woken up from PIR event  
      for(int i = 0; i < 10000; i++); 
      Init_RF ();                           //Initialize RF peripheral
      LED_on_Lights(); 
      
      RF_InfoInit(&RF_Info);                // Init RF_Info data structure
      TxRawDataInit(&RF_Info);				// Init ID to raw data
      TXRawDataPacketEnd(&RF_Info);         // Add end data

      TXCTRL->TXCTRL0 &= (~TXCTRL0_STARTX);
      NVIC_DisableIRQ( TX_RELOAD_IRQn );
      NVIC_DisableIRQ( TX_DONE_IRQn );
      NVIC_EnableIRQ( TX_RELOAD_IRQn );
      NVIC_EnableIRQ( TX_DONE_IRQn );
      
      uint16_t message=0x5555;
      RF_Info.Key=(uint8_t)message;
      TX_Start(&RF_Info);
      while (DataSending);           	// Got to sleep if RF is not done
      for(int i = 0; i < 10000; i++);
      LED_off();
  }
  
     register uint16_t btn_vals = readButtons();         // Read button status
 
     if(btn_vals == BUTTON_0)
     {
        while(1)
        {
          LED_on_Lights(); 
          //Reading ADC data    
          *ADCCTRL0 |= ADCCTRL0_ADCEN; //ADC enabled and start
          for(int i=0;i<100;i++);
          *ADCCTRL0 &= (~ADCCTRL0_ADCEN); //ADC enabled and stopped. 
   
          //update RAM data
          uint8_t data = *ADCRES;
        
          for(int i=0;i<1000;i++); //wait for some time
       
        }
     }
     *ADCCTRL0 = 0x00;
     ADCREF->HWORD = 0x2F0F;
     go_to_sleep();
  
}

//********* ISRs ************
void TX_Reload_Handler( void )
{
  TXDAT->HWORD = RF_Info.RawData[rf_data_idx++];   // write the new data and increment the index
  if ((rf_data_idx) > BURST_HWORD_SIZE) rf_data_idx=0;
}

void TX_Done_Handler( void ) 
{
  DataSendingEnable--;
  if (DataSendingEnable){
    TXDAT->HWORD = RF_Info.RawData[0];
    rf_data_idx=1;
    TXCTRL->TXCTRL0 |=  TXCTRL0_STARTX | TXCTRL0_NXTBURST;      //Init Transmission
  } 
  else {
    TXCTRL->TXCTRL0 &= ~(TXCTRL0_STARTX | TXCTRL0_NXTBURST);    // Clear both of the flags to fully stop TX
    DataSending=0;
  }
}

void Wakeup_Handler( void )
{
}

void Default_IRQ_Handler( void )
{
}

void Timer0_Handler( void )
{
}

void Timer1_Handler( void )
{
  TIMER1->COUNT = (-56250000);          		//Reload Register for every 400 ms
}
void Timer2_Handler( void )
{
  
}

void Watchdog_Handler( void )
{
}


//***************************** End of File ************************************