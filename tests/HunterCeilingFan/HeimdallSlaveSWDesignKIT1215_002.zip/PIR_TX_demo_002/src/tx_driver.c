#include "main.h"
#include "heimdallslave.h"

///////////////////////////////////////////
// Init RF_Info structure data
//
// Input: RF_InfoType*
// Output: none
// Variables changed:
//       (RF_InfoType*).pRawKeyDataEntryHword
//       (RF_InfoType*).RawKeyDataEntryBit
//
///////////////////////////////////////////
void RF_InfoInit(RF_InfoType *RF_InfoStr){
  RF_InfoStr->pRawKeyDataEntryHword = RF_InfoStr->RawData;
  RF_InfoStr->RawKeyDataEntryBit=0x8000;
}

///////////////////////////////////////////
// Init ID raw data for TX
//
// Input:((RF_InfoType*).RawData[]
//       (RF_InfoType*).pRawKeyDataEntryHword 
//       (RF_InfoType*).RawKeyDataEntryBit
// Output: none 
// Variables changed:
//       (RF_InfoType*).pRawKeyDataEntryHword
//       (RF_InfoType*).RawKeyDataEntryBit
//
///////////////////////////////////////////
void TxRawDataInit(RF_InfoType *RF_InfoStr){
  uint8_t RawBitMask;
  uint32_t BitMask;
  

#if (TX_PREAMBLE_BITS)
//Preamble
  BitMask=(0x00000001 << (TX_PREAMBLE_BITS-1));
  for (; BitMask; BitMask >>= 1){
    if (BitMask & TX_PREAMBLE)  *RF_InfoStr->pRawKeyDataEntryHword |= RF_InfoStr->RawKeyDataEntryBit;
    else *RF_InfoStr->pRawKeyDataEntryHword &= (~RF_InfoStr->RawKeyDataEntryBit);
    if (!(RF_InfoStr->RawKeyDataEntryBit >>= 1)) {
      RF_InfoStr->pRawKeyDataEntryHword++;
      RF_InfoStr->RawKeyDataEntryBit=0x8000;
    }
  }
#endif

// ID
  BitMask=(0x00000001 << (TX_ID_BITS-1));
  for (; BitMask; BitMask >>= 1){
    RawBitMask=0x01;
    RawBitMask <<= (N_RAW_BITS-1);
    if (BitMask & TX_ID)
      for (; RawBitMask; RawBitMask >>= 1){
        if (RAW_BIT_1 & RawBitMask) *RF_InfoStr->pRawKeyDataEntryHword |= RF_InfoStr->RawKeyDataEntryBit;
        else *RF_InfoStr->pRawKeyDataEntryHword &= (~RF_InfoStr->RawKeyDataEntryBit);
        if (!(RF_InfoStr->RawKeyDataEntryBit >>= 1)) {
          RF_InfoStr->pRawKeyDataEntryHword++;
          RF_InfoStr->RawKeyDataEntryBit=0x8000;
        }
      }
    else {
       for (; RawBitMask; RawBitMask >>= 1) {
        if (RAW_BIT_0 & RawBitMask) *RF_InfoStr->pRawKeyDataEntryHword |= RF_InfoStr->RawKeyDataEntryBit;
        else *RF_InfoStr->pRawKeyDataEntryHword &= (~RF_InfoStr->RawKeyDataEntryBit);
        if (!(RF_InfoStr->RawKeyDataEntryBit >>= 1)) {
          RF_InfoStr->pRawKeyDataEntryHword++;
          RF_InfoStr->RawKeyDataEntryBit=0x8000;
        }
      }
    }
  }
}

///////////////////////////////////////////
// Add stop bit for TX
//
// Input:(RF_InfoType*).nKey
//       (RF_InfoType*).pRawKeyDataEntryHword 
//       (RF_InfoType*).RawKeyDataEntryBit
// Output: none 
// Variables changed:
//       (RF_InfoType*).pRawKeyDataEntryHword
//       (RF_InfoType*).RawKeyDataEntryBit
//
///////////////////////////////////////////
void TXRawDataPacketEnd(RF_InfoType *RF_InfoStr){
  uint8_t i;
  volatile uint16_t* pRawData;
  uint16_t RawKeyBitMask;
  
  pRawData=RF_InfoStr->pRawKeyDataEntryHword;   // Point to the entry HWORD point of data buffers for storing key data
  RawKeyBitMask=RF_InfoStr->RawKeyDataEntryBit; // Prepare for bit mask value
  for (i=0; i<KEY_STOP_RAW_BIT_COUNT; i++){
    if (i == (KEY_STOP_RAW_BIT_COUNT-8)) *pRawData |= RawKeyBitMask;  // Insert raw stop bit
    else *pRawData &= (~(RawKeyBitMask));
     if (!(RawKeyBitMask >>= 1)) {
      pRawData++;
      RawKeyBitMask=0x8000;
     }
  }
}

///////////////////////////////////////////
// Add key raw data & stop bit for TX
//
// Input:(RF_InfoType*).nKey
//       (RF_InfoType*).RawData[]
//       (RF_InfoType*).pRawKeyDataEntryHword 
//       (RF_InfoType*).RawKeyDataEntryBit
// Output: none 
// Variables changed:
//       (RF_InfoType*).pRawKeyDataEntryHword
//       (RF_InfoType*).RawKeyDataEntryBit
//
///////////////////////////////////////////
void TxRawDataKeyAdded(RF_InfoType *RF_InfoStr){
  uint8_t RawBitMask,BitMask;
  volatile uint16_t* pRawData;
  uint16_t RawKeyBitMask;

  pRawData=RF_InfoStr->pRawKeyDataEntryHword;   // Point to the entry HWORD point of data buffers for storing key data
  BitMask=(0x01UL << (RF_InfoStr->nKey-1));     // Build a mask for filter key bits
  RawKeyBitMask=RF_InfoStr->RawKeyDataEntryBit; // Prepare for raw bit mask value
  for (; BitMask; BitMask >>= 1){
    RawBitMask=0x01;
    RawBitMask <<= (N_RAW_BITS-1);
    if (BitMask & RF_InfoStr->Key)
      for (; RawBitMask; RawBitMask >>= 1){
        if (RAW_BIT_1 & RawBitMask) *pRawData |= RawKeyBitMask;
        else *pRawData &= (~RawKeyBitMask);
        if (!(RawKeyBitMask >>= 1)) {
          pRawData++;
          RawKeyBitMask=0x8000;
        }
      }
    else
       for (; RawBitMask; RawBitMask >>= 1) {
        if (RAW_BIT_0 & RawBitMask) *pRawData |= RawKeyBitMask;
        else *pRawData &= (~RawKeyBitMask);
        if (!(RawKeyBitMask >>= 1)) {
          pRawData++;
          RawKeyBitMask=0x8000;
        }
      }
  }
  // End of the packet (stop bit)
//  *pRawData |= RawKeyBitMask;
}

//////////////////////////////////////////////////////////////////////////
/// @brief Set the transmitter into a low current mode prior to deep sleep
///
/// This function disables the transmitter in such a way as to ensure that
/// ultra-low current consumption can be achieved during deep sleep.  If is
/// strongly advised that this function be called prior to initiating a
/// deep sleep.
///
/// note:  The main code should ensure that another 150 MCU clocks occur
///        between this function's completion and deep sleep.
/// note:  the RC oscillator will be active and crystal disabled after this
///        code completes.
///
///////////////////////////////////////////////////////////////////////////
void TXDriver_Shutdown( void )
{
  ///////////////////////////////////////////        
  // DK's procedure to avoid potential rare occurrence floating net in PFD: 
  //   1 - turn RF on
  //   2 - wait until PLL turns on
  //   3 - change to RC oscillator
  //   4 - disable XTL bias.    
  //       
  // set the clock speed to full speed.
  // *CLKCTRL = CLKCTRL_SRC_XTAL | CLKCTRL_CLKDIV_1 | CLKCTRL_TRIMDIV;
  
  // disable the interrupts
  NVIC_DisableIRQ( TX_RELOAD_IRQn );
  NVIC_DisableIRQ( TX_DONE_IRQn );
  
  TXTIMING->CLKDIV.HWORD = (1 << 0)  |  // TXCLKDIV[9:0] <= 1
                           (0 << 10) ;  // TPATCH[4:0]   <= 1
  
  TXTIMING->TDET.HWORD   = (0 << 0)  |  // TDET4[4:0] <= 0
                           (0 << 5)  |  // TDET3[2:0] <= 0
                           (0 << 8)  |  // TDET1      <= 0
                           (0 << 9)  |  // TDET2[2:0] <= 0
                           (0 << 12) ;  // TRAMP[3:0] <= 0

  // TXCTRL2.BYTE[1] = 0x00;            /* TXCTRL2.BYTE[1] @ (ASIC_7B_BASE + 0x0B) */
  // TXCTRL2.BYTE[0] = 0x07;            /* TXCTRL2.BYTE[0] @ (ASIC_7B_BASE + 0x0A) */
  TXMSGFMT->HWORD = 0x0007;
  
  // PLLCTRL.BYTE[0] = 0x06;            /* PLLCTRL.BYTE[0] @ (ASIC_16B_BASE + 0x04)*/
  // PLLCTRL.BYTE[1] = 0x2D;            /* PLLCTRL.BYTE[1] @ (ASIC_16B_BASE + 0x05)*/
  // PLLCTRL.BYTE[2] = 0xCB;            /* PLLCTRL.BYTE[2] @ (ASIC_16B_BASE + 0x06)*/
  PLLCTRL->WORD = 0x00CB2D06;

  // TXCTRL->POWLEV = 0
  // TXCTRL->POWAP = 0
  *((uint16_t *) &(TXCTRL->POWLEV)) = 0x0000;
  
  // Change to the clock source to 10kHz with CLKDIV =8
  *CLKCTRL = CLKCTRL_SRC_RC | CLKCTRL_CLKDIV_8 | CLKCTRL_TRIMDIV;
  
  // Stop Transmit
  TXCTRL->TXCTRL0 = TXCTRL0_MODUL_ASK | TXCTRL0_FRAC_EN;
  
  //Disable Xtal
  *UCCTRL = UCCTRL_RCOSCEN | 0x40;
}

///////////////////////////////////////////
// Power down
//
// Input: none
// Output: none 
// Variables none
//
///////////////////////////////////////////
// remember toggle state and enter deep sleep.  if DEBUG_DSLP_LVL<2 (debug mode) then this function may instead
// wait for some condition and then return.
void go_to_sleep( void )
{
   register uint16_t temph;
  int32_t tmr0;
          
  // *** if we get here then we are committed to enter a deep sleep ***

  // set the radio to low current state prior to sleeping.
  // note:  this function disables the crystal oscillator and sets active clock source to RC
  TXDriver_Shutdown();
  
  // wait for 1500 ticks - 150ms
  tmr0 = TIMER0->COUNT + 150;
  while( (TIMER0->COUNT - tmr0) < 0 );
  


  // set pin io wake up conditions (default levels and interrupt gen enables)
  // wake up if pins change from their current values...
  temph = GPIO->HWORD;
  *GPIOCTRL1 = (uint8_t) temph;                // IODEF[7:0] <= GPIO[7:0]]
  *GPIOCTRL2 = ((BTN_PORTMASK >> 4) & 0xF0) |  // { IOCEN[11:8] , IODEF[11:8] } <= { BTN_PORTMASK[11:8] , GPIO[11:8] }
               ((temph >> 8) & 0x0F);          
  *GPIOCTRL3 = (uint8_t) BTN_PORTMASK;         // IOCEN[7:0] <= BTN_PORTMASK[7:0]
  
  // switch to RC oscillator
  *CLKCTRL = CLKCTRL_SRC_RC | CLKCTRL_CLKDIV_8 | CLKCTRL_TRIMDIV;

//Modify for PIR wakeup
  PIR->PIRCNTR = 0x38;                  // Set PIR event threshold counter
//  PIR->PIRCTRL = 0x04|(11<<4);        // Setup inhibit counter. Eiter one of PIR divider bits has to be one for PIR wakeup.
                                        // One min and 54 seconds inhibit
  PIR->PIRCTRL = 0x04|(0x02<<4);        // Two seconds inhibit
  *PIR_WAKEUP &= (~ PIR_WUF);           // Clear PIR INT flag
  
  // go to sleep
  *RCOCTRL = RCOCTRL_CALMODE_MANUAL;            // Auto calibration on 10KHz clock & calibration value is 0
  *UCCTRL = UCCTRL_RCOSCEN | UCCTRL_PIREN | UCCTRL_WKTEN;
  while(1) *UCCTRL = UCCTRL_SWPWRDN | UCCTRL_RCOSCEN|UCCTRL_PIREN | UCCTRL_WKTEN;  // Wait for sleep
}

///////////////////////////////////////////
// Update key raw data for TX
//
// Input:(RF_InfoType*).Keys
//       (RF_InfoType*).RawData[]
// Output: none 
// Variables changed:
//       DataSending;
//       rf_data_idx;
//
///////////////////////////////////////////
void TX_Start ( RF_InfoType *RF_InfoStr ){
  TxRawDataKeyAdded(&RF_Info);                  // Add key to raw data
  TXDAT->HWORD = RF_InfoStr->RawData[0];        // Load the first TX data to TX buffer
  rf_data_idx = 1;                              // Point to next TX data
  DataSendingEnable=10;                          // Flag to enable TX sending
  DataSending=1;                                // To indicate TX is sending
  TXCTRL->TXCTRL0 = TXCTRL0_MODUL_ASK | TXCTRL0_FRAC_EN | TXCTRL0_STARTX | TXCTRL0_NXTBURST;    // Start TX
}

/**
* @brief Function to initialize RF peripheral
*
* @param none
* @return none
* NOTE: 
*/
void Init_RF (void)
{
  // {STARTCAL, FREQSEL, CALMODE, CALVAL[4...0]}
  *RCOCTRL &= 0x08;               //Define crystal as 30MHz
  
  // set TDelay & data rate (CDIV = 500, Symbol rate = 2.5kbps)
  // TXCTRLB->BYTE[3] => { TDET3[2:0] , TDET4[4:0] }
  // TXCTRLB->BYTE[2] => { TRAMP[3:0] , TDET2[2:0] , TDET1 }
  // TXCTRLB->BYTE[1] => { TPATCH[4:0] , CDIV[10:8] }
  // TXCTRLB->BYTE[0] => { CDIV[7:0] }


  //TXCTRLB->WORD    = 0x908501F4;
  //  TXCTRLB->WORD    = 0x908503E8;  
  //  TXCTRLB->WORD    = 0x90850343;  

  // Set TPATCH & symbol rate
  TXTIMING->CLKDIV.HWORD = (TPATCH << 11)|(CDIV & 0x07FF);      // CDIV=375, Symbol rate =3.3K;
  // TXTIMING->TDET.HWORD={ TRAMP[3:0] , TDET2[2:0] , TDET1 , TDET3[2:0] , TDET4[4:0] }
  TXTIMING->TDET.HWORD = (TXTIMING->TDET.HWORD & 0xFF00)| (TDET3 << 5) | TDET4;

  // set Nburst and Nwait time
  //  TXCTRLA->HWORD   = 0xA8EF;
  TXMSGFMT->HWORD = (NWAIT << 10)|BURST_BIT_SIZE;  
  
  // set PLL parameters (Nx,Nf,DF,CP_TRIM and LPF_TRIM)
  // PLLTRIM->BYTE[3] => { DF[5:0] , LPF_TRM[3:2] }
  // PLLTRIM->BYTE[2] => { LPF_TRM[1:0] , CP_TRM[2:0] , NX[4:2] }
  // PLLTRIM->BYTE[1] => { NX[1:0] , NF[13:8] }
  // PLLTRIM->BYTE[0] => { NF[7:0] }
  PLLCTRL->WORD = 0x00C95DB2; // 433.92Mhz
  
  // set TX mode and power level
  // TXCONFIG->BYTE[3] => { ASKAMP[7:0] } //POWER Control --> 0xFF = Max power
  // TXCONFIG->BYTE[2] => { POWLEV[7:0] }
  // TXCONFIG->BYTE[1] => { PEDES[1:0] , tPatch[10:5] }
  // TXCONFIG->BYTE[0] => { START , NEXT , MODE[1:0] , FRAC_EN , 3'b000 }
  TXCTRL->POWLEV = 0x00;
  TXCTRL->POWAP = 0x45;			        // 47=10dBm, 28=6dBm, 14=0dBm,RBW/VBW=100Khz  ORIGINAL 1/5/2012
//  TXCONFIG->BYTE[3] = 0x00;                   // 47=10dBm, 28=6dBm, 14=0dBm,RBW/VBW=100Khz 
  TXCTRL->TXCTRL0 = TXCTRL0_MODUL_ASK | TXCTRL0_FRAC_EN; // | TXCONFIG0_START | TXCONFIG0_NEXT;  
  
  // enable rf buffer interrupt
  NVIC_EnableIRQ( TX_RELOAD_IRQn );
  NVIC_EnableIRQ( TX_DONE_IRQn   );  
}