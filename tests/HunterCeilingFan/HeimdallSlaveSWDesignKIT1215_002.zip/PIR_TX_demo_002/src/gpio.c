#include "main.h"
#include "heimdallslave.h"

//-----------------------------------------
//
//
//-----------------------------------------
  void Init_GPIO (void)
  {
    *GPIOPUL1 = GPIOPUL1_CFGVAL;
    *GPIOPUL2 = GPIOPUL2_CFGVAL;
    *GPIOPUL3 = GPIOPUL3_CFGVAL;
    GPIOOE->HWORD = GPIOOE_CFGVAL;
    GPIORE->HWORD = GPIORE_CFGVAL;
  }


// turn on the (BLUE) LED (for a light-related function)
void LED_on_Lights( void )
{
  if( HAS_LED )
  {
    GPIOOE->BYTE[1] = 0x50 | (GPIOOE_CFGVAL >> 8);
    *LEDTRIM        = 0x11;
  }
}


// turn off the LED
void LED_off( void )
{
  if( HAS_LED )
  {
    GPIOOE->BYTE[1] = (GPIOOE_CFGVAL >> 8);
    *LEDTRIM        = 0x00;
  }
}


// read the buttons with a simple debounce.  return the buttons vector indicating a 1 for each control which is being
// pressed (or toggle changed from boot up value in the case of a reverse toggle).
uint16_t readButtons( void )
{
  uint16_t temph, temphz;
  uint8_t  tgl_pin_now;
  int32_t tmr0;

  // read the port and mask it
  temph = GPIO->HWORD;
  temph |= (~BTN_PORTMASK);
  
  // debounce
  do {
    // shift
    temphz = temph;
    
    // debounce delay
    tmr0 = TIMER0->COUNT + DEBOUNCE_COUNTS;
    while( (TIMER0->COUNT - tmr0) < 0 );   // ring math makes this work even if TIMER0 wraps
    
    // measure again
    temph = GPIO->HWORD;
    temph |= (~BTN_PORTMASK);
    
  } while( temph != temphz );
  
  // fix up the vector
  temph = ~temph;   // most buttons are inverted
  
  return temph;
}

void Init_ADC (void)
{
  *ADCCTRL0 = ADCCTRL0_ADCCLK_DIV32;
  *ADCMUX = ADCMUX_GPIO5;
  //*ADCMUX = ADCMUX_TEMPSNS;
 // *ADC1REF = ADCREFLO | ADCREFHI;
  ADCREF->BYTE[0] = ADCREFLO | ADCREFHI;
  ADCREF->BYTE[1] |= ADCREFVDD; 
  ADCREF->BYTE[1] = (ADCREF->BYTE[1] & 0xF0) | ADCPGN;
}

