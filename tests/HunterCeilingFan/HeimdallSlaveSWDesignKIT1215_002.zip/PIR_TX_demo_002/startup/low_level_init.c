#include <stdint.h>
#include "heimdallslave.h"

extern  uint16_t iovalue;
extern  uint16_t iovalue1;
extern  uint16_t initial_buttons;

#ifdef __cplusplus
extern "C" {
#endif

#pragma language=extended

// ****************************************************************************
// __low_level_init() is called before data initialization (copy of 
// initialized variables from flash to SRAM).  Anything that must be done
// quickly after a reset should be done here, but beware that any variables 
// have not been initialized yet, so using their value will result in
// unpredictable values being used, and setting their value will result in the
// later data initialization overwriting your result.
//
// If you need to skip the data initialization prior to main(), then you can
// have the function return zero.  Be aware that all variables will be
// uninitialized and will contain unpredictable data at the point of the start
// of main() execution.
// ****************************************************************************

__interwork int __low_level_init(void);

__interwork int __low_level_init(void)
{
  // ASIC register clear
  // *UCCTRL = UCCTRL_SOFTCLR;
  
  // Enable the crystal oscillator bias
  *UCCTRL = UCCTRL_RCOSCEN  |   // RC oscillator enabled
            UCCTRL_AUTOXTAL |   // XTAL oscillator auto-enabled after sleep
            UCCTRL_SWXTALEN |   // XTAL manually enabled
            UCCTRL_PIREN;       // PIR enable

  // Set TIMER0 to time crystal oscillator settling.
  // fRC ~= 10kHz.  To wait 10ms for startup we need to
  // count to 100
  TIMER0->COUNT = -150;
  TIMER0->CTRL   = TIMER_CFG_ENA;
			
  // Set flash access speed to be appropriate for 30MHz clock
  FLASH_CTRL->FLSCTRL = FLSCTRL_16TO32MHZ;
     
  // wait for XTAL settling to get done
  while( TIMER0->COUNT < 0 );
  
  // Set crystal oscillator as clock source
   *CLKCTRL = CLKCTRL_TRIMDIV  |  // reserved - have to write this value
              CLKCTRL_SRC_XTAL |  // clock source is XTAL
              CLKCTRL_CLKDIV_1;   // no clock division		  
    
  // Return value controls whether data initialization is performed
  //   0 ==> Omit initialization
  //   1 ==> Process seg_init        
  return 1;
}

#pragma language=default

#ifdef __cplusplus
}
#endif
