#pragma language=extended
#pragma segment="CSTACK"

#include "heimdallslave.h"

// IAR boot up function for vector table
extern void __iar_program_start( void );


// ****************************************************************************
// IRQ and exception handlers.  These will be defined and implemented
// here as __WEAK functions.  It is expected that the application code
// will override them as required.
// ****************************************************************************

extern void HardFault_Handler( void );
extern void SysTick_Handler( void );
extern void TX_Reload_Handler( void );
extern void TX_Done_Handler( void );
extern void Wakeup_Handler( void );
extern void Timer0_Handler( void );
extern void Timer1_Handler( void );
extern void Timer2_Handler( void );
extern void Watchdog_Handler( void );
extern void Default_IRQ_Handler( void );

__weak void HardFault_Handler( void )   {}
__weak void SysTick_Handler( void )     {} 
__weak void TX_Reload_Handler( void )   {}
__weak void TX_Done_Handler( void )     {}
__weak void Wakeup_Handler( void )      {}
__weak void Timer0_Handler( void )      {}
__weak void Timer1_Handler( void )      {}
__weak void Timer2_Handler( void )      {}
__weak void Watchdog_Handler( void )    {}
__weak void Default_IRQ_Handler( void ) {}

// ****************************************************************************
// vector table
// ****************************************************************************

// pointer to fuction typedef
typedef void( *intfunc )( void );
typedef union { intfunc __fun; void * __ptr; } intvec_elem;

// The interrupt vector table is located at address 0 in the linker config
#pragma location = ".intvec"
const intvec_elem __vector_table[] =
{
  { .__ptr = __sfe( "CSTACK" ) },    // stack top populated by linker
  __iar_program_start,               // reset vector.  this function will eventually call main()
  Default_IRQ_Handler,               // not implemented
  HardFault_Handler,                 // HardFault (e.g. bad memory access)
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  0,                                 // reserved
  0,                                 // reserved
  0,                                 // reserved
  0,                                 // reserved
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  0,                                 // reserved
  Default_IRQ_Handler,               // not implemented
  SysTick_Handler,                   // SysTick interrupt
  TX_Reload_Handler,                 // IRQ 0
  TX_Done_Handler,                   // IRQ 1
  Default_IRQ_Handler,               // not implemented
  Wakeup_Handler,                    // IRQ 3
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Default_IRQ_Handler,               // not implemented
  Timer0_Handler,                    // TIMER0 overflow interrupt
  Timer1_Handler,                    // TIMER1 overflow interrupt
  Timer2_Handler,                    // TIMER2 overflow interrupt
  Watchdog_Handler                   // WTD interrupt
};


// ****************************************************************************
// boot up function
// ****************************************************************************

void __cmain( void );
__weak void __iar_init_core( void );
__weak void __iar_init_vfp( void );

#pragma required=__vector_table
void __iar_program_start( void )
{
  // Enable the crystal oscillator bias
  *UCCTRL = UCCTRL_RCOSCEN  |   // RC oscillator enabled
            UCCTRL_AUTOXTAL |    // XTAL oscillator auto-enabled after sleep
            UCCTRL_SWXTALEN |    // XTAL manually enabled
            UCCTRL_WKTEN;        // Wakeup timer enabled
  __iar_init_core();
  __iar_init_vfp();
  __cmain();
}
